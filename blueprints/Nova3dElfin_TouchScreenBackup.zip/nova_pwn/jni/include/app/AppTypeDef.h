/*
 * AppTypeDef.h
 *
 *  Created on: Oct 25, 2017
 *      Author: guoxs
 */

#ifndef _APP_APPTYPEDEF_H_
#define _APP_APPTYPEDEF_H_

#define APP_TYPE_ACTIVITY			0
#define APP_TYPE_SYS_STATUSBAR		1
#define APP_TYPE_SYS_NAVIBAR		2
#define APP_TYPE_SYS_SCREENSAVER	3
#define APP_TYPE_SYS_IME			4

#endif /* _APP_APPTYPEDEF_H_ */
