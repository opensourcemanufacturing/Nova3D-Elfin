/***********************************************
/gen auto by zuitools
***********************************************/
#ifndef __FILEMANAGERACTIVITY_H__
#define __FILEMANAGERACTIVITY_H__


#include "app/Activity.h"
#include "entry/EasyUIContext.h"

#include "uart/ProtocolData.h"
#include "uart/ProtocolParser.h"

#include "utils/Log.h"
#include "control/ZKDigitalClock.h"
#include "control/ZKPainter.h"
#include "control/ZKButton.h"
#include "control/ZKCircleBar.h"
#include "control/ZKDiagram.h"
#include "control/ZKListView.h"
#include "control/ZKPointer.h"
#include "control/ZKQRCode.h"
#include "control/ZKTextView.h"
#include "control/ZKSeekBar.h"
#include "control/ZKEditText.h"
#include "control/ZKVideoView.h"
#include "window/ZKSlideWindow.h"

/*TAG:Macro宏ID*/
#define ID_FILEMANAGER_UsbFileCancellButton    20032
#define ID_FILEMANAGER_UsbFilePageDownButton    20031
#define ID_FILEMANAGER_UsbFilePageUpbutton    20030
#define ID_FILEMANAGER_UsbFileSureButton    20029
#define ID_FILEMANAGER_UsbFileListButton6    20028
#define ID_FILEMANAGER_UsbFileListButton5    20027
#define ID_FILEMANAGER_UsbFileListButton4    20026
#define ID_FILEMANAGER_UsbFileListButton3    20025
#define ID_FILEMANAGER_UsbFileListButton2    20024
#define ID_FILEMANAGER_UsbFileListButton1    20023
#define ID_FILEMANAGER_UsbFileListsWindow    110003
#define ID_FILEMANAGER_UsbFilesWindow    110004
#define ID_FILEMANAGER_PrintButton3Painter2    52007
#define ID_FILEMANAGER_PrintButton3Painter1    52006
#define ID_FILEMANAGER_PrintButton2Painter2    52005
#define ID_FILEMANAGER_PrintButton2Painter1    52004
#define ID_FILEMANAGER_PrintButton1Painter2    52003
#define ID_FILEMANAGER_PrintButton1Painter1    52002
#define ID_FILEMANAGER_DeleteButton3    20016
#define ID_FILEMANAGER_PrintButton3    20015
#define ID_FILEMANAGER_DeleteButton2    20014
#define ID_FILEMANAGER_PrintButton2    20013
#define ID_FILEMANAGER_DeleteButton1    20012
#define ID_FILEMANAGER_PrintButton1    20009
#define ID_FILEMANAGER_FileListButton3    20011
#define ID_FILEMANAGER_FileListButton2    20010
#define ID_FILEMANAGER_FileListButton1    20008
#define ID_FILEMANAGER_FileListWindow    110002
#define ID_FILEMANAGER_PrintConfirmTextview2    50004
#define ID_FILEMANAGER_PrintConfirmTextview    50003
#define ID_FILEMANAGER_DeleteConfirmTextview    50001
#define ID_FILEMANAGER_CancelButton    20007
#define ID_FILEMANAGER_ConfirmButton    20006
#define ID_FILEMANAGER_FileDialogWindow    110001
#define ID_FILEMANAGER_PageNumberTextview    50002
#define ID_FILEMANAGER_PageDownButton    20005
#define ID_FILEMANAGER_PageUpButton    20004
#define ID_FILEMANAGER_backButton    20001
#define ID_FILEMANAGER_sys_back   100
#define ID_FILEMANAGER_Painter1    52001
#define ID_FILEMANAGER_LocalFileButton    20002
#define ID_FILEMANAGER_ExternalFileButton    20003
#define ID_FILEMANAGER_ButtonsWindow    110005
/*TAG:Macro宏ID END*/

class fileManagerActivity : public Activity, 
                     public ZKSeekBar::ISeekBarChangeListener, 
                     public ZKListView::IItemClickListener,
                     public ZKListView::AbsListAdapter,
                     public ZKSlideWindow::ISlideItemClickListener,
                     public EasyUIContext::ITouchListener,
                     public ZKEditText::ITextChangeListener,
                     public ZKVideoView::IVideoPlayerMessageListener
{
public:
    fileManagerActivity();
    virtual ~fileManagerActivity();

    /**
     * 注册定时器
     */
	void registerUserTimer(int id, int time);
	/**
	 * 取消定时器
	 */
	void unregisterUserTimer(int id);
	/**
	 * 重置定时器
	 */
	void resetUserTimer(int id, int time);

protected:
    /*TAG:PROTECTED_FUNCTION*/
    virtual const char* getAppName() const;
    virtual void onCreate();
    virtual void onClick(ZKBase *pBase);
    virtual void onResume();
    virtual void onPause();
    virtual void onIntent(const Intent *intentPtr);
    virtual bool onTimer(int id);

    virtual void onProgressChanged(ZKSeekBar *pSeekBar, int progress);

    virtual int getListItemCount(const ZKListView *pListView) const;
    virtual void obtainListItemData(ZKListView *pListView, ZKListView::ZKListItem *pListItem, int index);
    virtual void onItemClick(ZKListView *pListView, int index, int subItemIndex);

    virtual void onSlideItemClick(ZKSlideWindow *pSlideWindow, int index);

    virtual bool onTouchEvent(const MotionEvent &ev);

    virtual void onTextChanged(ZKTextView *pTextView, const string &text);

    void rigesterActivityTimer();

    virtual void onVideoPlayerMessage(ZKVideoView *pVideoView, int msg);
    void videoLoopPlayback(ZKVideoView *pVideoView, int msg, size_t callbackTabIndex);
    void startVideoLoopPlayback();
    void stopVideoLoopPlayback();
    bool parseVideoFileList(const char *pFileListPath, std::vector<string>& mediaFileList);
    int removeCharFromString(string& nString, char c);


private:
    /*TAG:PRIVATE_VARIABLE*/
    int mVideoLoopIndex;
    int mVideoLoopErrorCount;

};

#endif