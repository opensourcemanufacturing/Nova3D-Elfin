/***********************************************
/gen auto by zuitools
***********************************************/
#ifndef __PRINTCONTROLACTIVITY_H__
#define __PRINTCONTROLACTIVITY_H__


#include "app/Activity.h"
#include "entry/EasyUIContext.h"

#include "uart/ProtocolData.h"
#include "uart/ProtocolParser.h"

#include "utils/Log.h"
#include "control/ZKDigitalClock.h"
#include "control/ZKPainter.h"
#include "control/ZKButton.h"
#include "control/ZKCircleBar.h"
#include "control/ZKDiagram.h"
#include "control/ZKListView.h"
#include "control/ZKPointer.h"
#include "control/ZKQRCode.h"
#include "control/ZKTextView.h"
#include "control/ZKSeekBar.h"
#include "control/ZKEditText.h"
#include "control/ZKVideoView.h"
#include "window/ZKSlideWindow.h"

/*TAG:Macro宏ID*/
#define ID_PRINTCONTROL_ConfirmButton    20021
#define ID_PRINTCONTROL_CancelButton    20020
#define ID_PRINTCONTROL_ContentTextview    50002
#define ID_PRINTCONTROL_TitleTextview    50001
#define ID_PRINTCONTROL_ResetDialogWindow    110003
#define ID_PRINTCONTROL_LevelingConfirmButton    20038
#define ID_PRINTCONTROL_LevelingCancelButton    20037
#define ID_PRINTCONTROL_SaveWindow    110005
#define ID_PRINTCONTROL_AdjustOriginButton    20019
#define ID_PRINTCONTROL_SLCConfigButton    20012
#define ID_PRINTCONTROL_PlatformLiftingButton    20011
#define ID_PRINTCONTROL_LevelingClearButton    20017
#define ID_PRINTCONTROL_LevelingZeroButton    20016
#define ID_PRINTCONTROL_LevelingSaveButton    20015
#define ID_PRINTCONTROL_LevelingDownButton    20014
#define ID_PRINTCONTROL_LevelingRiseButton    20013
#define ID_PRINTCONTROL_PlatformLevelingWindow    110001
#define ID_PRINTCONTROL_Painter2    52002
#define ID_PRINTCONTROL_BottomExpoButton    20036
#define ID_PRINTCONTROL_BottomExpoMinusButton    20035
#define ID_PRINTCONTROL_Painter6    52006
#define ID_PRINTCONTROL_BottomExpoPlusButton    20034
#define ID_PRINTCONTROL_BottomExpoEdittext    51005
#define ID_PRINTCONTROL_PlatformSpeedButton    20033
#define ID_PRINTCONTROL_PlatformSpeedMinusButton    20032
#define ID_PRINTCONTROL_Painter5    52005
#define ID_PRINTCONTROL_PlatformSpeedPlusButton    20031
#define ID_PRINTCONTROL_PlatformSpeedEdittext    51004
#define ID_PRINTCONTROL_BottomLayerNumButton    20030
#define ID_PRINTCONTROL_BottomNumMinusButton    20029
#define ID_PRINTCONTROL_Painter4    52004
#define ID_PRINTCONTROL_BottomNumPlusButton    20028
#define ID_PRINTCONTROL_BottomLayerNumEdittext    51003
#define ID_PRINTCONTROL_NormLayerExpoButton    20024
#define ID_PRINTCONTROL_NormLayerExpoEdittext    51001
#define ID_PRINTCONTROL_NormLayerMinusButton    20023
#define ID_PRINTCONTROL_NormLayerPlusButton    20022
#define ID_PRINTCONTROL_SLCConfigWindow    110004
#define ID_PRINTCONTROL_DownButton50    20010
#define ID_PRINTCONTROL_DownButton10    20009
#define ID_PRINTCONTROL_DownButton1    20008
#define ID_PRINTCONTROL_DownButton0_05    20007
#define ID_PRINTCONTROL_RiseButton50    20006
#define ID_PRINTCONTROL_RiseButton10    20005
#define ID_PRINTCONTROL_ResetButton    20004
#define ID_PRINTCONTROL_RiseButton1    20003
#define ID_PRINTCONTROL_RiseButton0_05    20002
#define ID_PRINTCONTROL_PlatformLiftingWindow    110002
#define ID_PRINTCONTROL_Painter1    52001
#define ID_PRINTCONTROL_sys_back   100
#define ID_PRINTCONTROL_BackButton    20018
/*TAG:Macro宏ID END*/

class printControlActivity : public Activity, 
                     public ZKSeekBar::ISeekBarChangeListener, 
                     public ZKListView::IItemClickListener,
                     public ZKListView::AbsListAdapter,
                     public ZKSlideWindow::ISlideItemClickListener,
                     public EasyUIContext::ITouchListener,
                     public ZKEditText::ITextChangeListener,
                     public ZKVideoView::IVideoPlayerMessageListener
{
public:
    printControlActivity();
    virtual ~printControlActivity();

    /**
     * 注册定时器
     */
	void registerUserTimer(int id, int time);
	/**
	 * 取消定时器
	 */
	void unregisterUserTimer(int id);
	/**
	 * 重置定时器
	 */
	void resetUserTimer(int id, int time);

protected:
    /*TAG:PROTECTED_FUNCTION*/
    virtual const char* getAppName() const;
    virtual void onCreate();
    virtual void onClick(ZKBase *pBase);
    virtual void onResume();
    virtual void onPause();
    virtual void onIntent(const Intent *intentPtr);
    virtual bool onTimer(int id);

    virtual void onProgressChanged(ZKSeekBar *pSeekBar, int progress);

    virtual int getListItemCount(const ZKListView *pListView) const;
    virtual void obtainListItemData(ZKListView *pListView, ZKListView::ZKListItem *pListItem, int index);
    virtual void onItemClick(ZKListView *pListView, int index, int subItemIndex);

    virtual void onSlideItemClick(ZKSlideWindow *pSlideWindow, int index);

    virtual bool onTouchEvent(const MotionEvent &ev);

    virtual void onTextChanged(ZKTextView *pTextView, const string &text);

    void rigesterActivityTimer();

    virtual void onVideoPlayerMessage(ZKVideoView *pVideoView, int msg);
    void videoLoopPlayback(ZKVideoView *pVideoView, int msg, size_t callbackTabIndex);
    void startVideoLoopPlayback();
    void stopVideoLoopPlayback();
    bool parseVideoFileList(const char *pFileListPath, std::vector<string>& mediaFileList);
    int removeCharFromString(string& nString, char c);


private:
    /*TAG:PRIVATE_VARIABLE*/
    int mVideoLoopIndex;
    int mVideoLoopErrorCount;

};

#endif