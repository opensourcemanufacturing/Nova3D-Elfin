/***********************************************
/gen auto by zuitools
***********************************************/
#ifndef __SYSTEMSETTINGSACTIVITY_H__
#define __SYSTEMSETTINGSACTIVITY_H__


#include "app/Activity.h"
#include "entry/EasyUIContext.h"

#include "uart/ProtocolData.h"
#include "uart/ProtocolParser.h"

#include "utils/Log.h"
#include "control/ZKDigitalClock.h"
#include "control/ZKPainter.h"
#include "control/ZKButton.h"
#include "control/ZKCircleBar.h"
#include "control/ZKDiagram.h"
#include "control/ZKListView.h"
#include "control/ZKPointer.h"
#include "control/ZKQRCode.h"
#include "control/ZKTextView.h"
#include "control/ZKSeekBar.h"
#include "control/ZKEditText.h"
#include "control/ZKVideoView.h"
#include "window/ZKSlideWindow.h"

/*TAG:Macro宏ID*/
#define ID_SYSTEMSETTINGS_ScreenCheckStarTextview    50011
#define ID_SYSTEMSETTINGS_ScreenCheckConfirmButton    20028
#define ID_SYSTEMSETTINGS_ScreenCheckResetDialogWindow    110005
#define ID_SYSTEMSETTINGS_ipTextview    50003
#define ID_SYSTEMSETTINGS_ipNameTextview    50004
#define ID_SYSTEMSETTINGS_EthernetWindow    110007
#define ID_SYSTEMSETTINGS_Textview13    50010
#define ID_SYSTEMSETTINGS_snsidText    50024
#define ID_SYSTEMSETTINGS_modelText    50023
#define ID_SYSTEMSETTINGS_Textview12    50022
#define ID_SYSTEMSETTINGS_Textview11    50021
#define ID_SYSTEMSETTINGS_Textview10    50020
#define ID_SYSTEMSETTINGS_Textview9    50019
#define ID_SYSTEMSETTINGS_Textview8    50018
#define ID_SYSTEMSETTINGS_Textview7    50017
#define ID_SYSTEMSETTINGS_Textview6    50016
#define ID_SYSTEMSETTINGS_Button9    20026
#define ID_SYSTEMSETTINGS_Painter14    52014
#define ID_SYSTEMSETTINGS_hardwareInfo    20025
#define ID_SYSTEMSETTINGS_HardwareInfoWindow    110009
#define ID_SYSTEMSETTINGS_Painter15    52015
#define ID_SYSTEMSETTINGS_sys_back2    20029
#define ID_SYSTEMSETTINGS_Button8    20030
#define ID_SYSTEMSETTINGS_LanguageSListview    80001
#define ID_SYSTEMSETTINGS_LanguageSelectWindow    110008
#define ID_SYSTEMSETTINGS_pgdown    20019
#define ID_SYSTEMSETTINGS_cancell    20018
#define ID_SYSTEMSETTINGS_pgup    20017
#define ID_SYSTEMSETTINGS_publicSure    20016
#define ID_SYSTEMSETTINGS_Button7    20015
#define ID_SYSTEMSETTINGS_Button6    20014
#define ID_SYSTEMSETTINGS_Button5    20013
#define ID_SYSTEMSETTINGS_Button4    20012
#define ID_SYSTEMSETTINGS_Button3    20011
#define ID_SYSTEMSETTINGS_Button2    20010
#define ID_SYSTEMSETTINGS_NetworkListWindow    110004
#define ID_SYSTEMSETTINGS_pointButton    20009
#define ID_SYSTEMSETTINGS_Painter7    52007
#define ID_SYSTEMSETTINGS_Painter6    52006
#define ID_SYSTEMSETTINGS_Painter5    52005
#define ID_SYSTEMSETTINGS_Painter4    52004
#define ID_SYSTEMSETTINGS_Painter3    52003
#define ID_SYSTEMSETTINGS_currentWIFIText    50002
#define ID_SYSTEMSETTINGS_Textview1    50001
#define ID_SYSTEMSETTINGS_Painter2    52002
#define ID_SYSTEMSETTINGS_ConnectButton    20002
#define ID_SYSTEMSETTINGS_passwordEdittext    51002
#define ID_SYSTEMSETTINGS_EthernetButton    20008
#define ID_SYSTEMSETTINGS_WifiButton    20007
#define ID_SYSTEMSETTINGS_NetworkSettingsWindow    110003
#define ID_SYSTEMSETTINGS_LanguageButton    20027
#define ID_SYSTEMSETTINGS_Version1Textview    50014
#define ID_SYSTEMSETTINGS_Version2Textview    50013
#define ID_SYSTEMSETTINGS_LanguageIconButton    20024
#define ID_SYSTEMSETTINGS_LanguageSelectButton    20023
#define ID_SYSTEMSETTINGS_HardwareSTextview    50009
#define ID_SYSTEMSETTINGS_apkVersionTextview    50005
#define ID_SYSTEMSETTINGS_Painter13    52013
#define ID_SYSTEMSETTINGS_Painter12    52012
#define ID_SYSTEMSETTINGS_Painter11    52011
#define ID_SYSTEMSETTINGS_Painter10    52010
#define ID_SYSTEMSETTINGS_Painter9    52009
#define ID_SYSTEMSETTINGS_Painter8    52008
#define ID_SYSTEMSETTINGS_LanguageSwitchButton    20022
#define ID_SYSTEMSETTINGS_hardwareButton    20021
#define ID_SYSTEMSETTINGS_versionButton    20020
#define ID_SYSTEMSETTINGS_LanguageSettingsWindow    110002
#define ID_SYSTEMSETTINGS_tipsTextview2_1    50012
#define ID_SYSTEMSETTINGS_tipsTextview3    50008
#define ID_SYSTEMSETTINGS_tipsTextview2    50007
#define ID_SYSTEMSETTINGS_tipsTextview1    50006
#define ID_SYSTEMSETTINGS_StartCheckButton    20003
#define ID_SYSTEMSETTINGS_ScreenCheckWindow    110001
#define ID_SYSTEMSETTINGS_NetworkSettingButton    20006
#define ID_SYSTEMSETTINGS_LanguageSettingButton    20005
#define ID_SYSTEMSETTINGS_ScreenCheckButton    20004
#define ID_SYSTEMSETTINGS_Painter1    52001
#define ID_SYSTEMSETTINGS_sys_back   100
#define ID_SYSTEMSETTINGS_Button1    20001
/*TAG:Macro宏ID END*/

class systemSettingsActivity : public Activity, 
                     public ZKSeekBar::ISeekBarChangeListener, 
                     public ZKListView::IItemClickListener,
                     public ZKListView::AbsListAdapter,
                     public ZKSlideWindow::ISlideItemClickListener,
                     public EasyUIContext::ITouchListener,
                     public ZKEditText::ITextChangeListener,
                     public ZKVideoView::IVideoPlayerMessageListener
{
public:
    systemSettingsActivity();
    virtual ~systemSettingsActivity();

    /**
     * 注册定时器
     */
	void registerUserTimer(int id, int time);
	/**
	 * 取消定时器
	 */
	void unregisterUserTimer(int id);
	/**
	 * 重置定时器
	 */
	void resetUserTimer(int id, int time);

protected:
    /*TAG:PROTECTED_FUNCTION*/
    virtual const char* getAppName() const;
    virtual void onCreate();
    virtual void onClick(ZKBase *pBase);
    virtual void onResume();
    virtual void onPause();
    virtual void onIntent(const Intent *intentPtr);
    virtual bool onTimer(int id);

    virtual void onProgressChanged(ZKSeekBar *pSeekBar, int progress);

    virtual int getListItemCount(const ZKListView *pListView) const;
    virtual void obtainListItemData(ZKListView *pListView, ZKListView::ZKListItem *pListItem, int index);
    virtual void onItemClick(ZKListView *pListView, int index, int subItemIndex);

    virtual void onSlideItemClick(ZKSlideWindow *pSlideWindow, int index);

    virtual bool onTouchEvent(const MotionEvent &ev);

    virtual void onTextChanged(ZKTextView *pTextView, const string &text);

    void rigesterActivityTimer();

    virtual void onVideoPlayerMessage(ZKVideoView *pVideoView, int msg);
    void videoLoopPlayback(ZKVideoView *pVideoView, int msg, size_t callbackTabIndex);
    void startVideoLoopPlayback();
    void stopVideoLoopPlayback();
    bool parseVideoFileList(const char *pFileListPath, std::vector<string>& mediaFileList);
    int removeCharFromString(string& nString, char c);


private:
    /*TAG:PRIVATE_VARIABLE*/
    int mVideoLoopIndex;
    int mVideoLoopErrorCount;

};

#endif